#!/bin/bash

rm -r dist
python setup.py sdist