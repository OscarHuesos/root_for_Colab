===========================================
:mod:`XRootD.client.URL`: XRootD URL object
===========================================

Class Reference
---------------

.. module:: XRootD.client

.. autoclass:: XRootD.client.URL()

Methods
*******

.. automethod:: XRootD.client.URL.is_valid
.. automethod:: XRootD.client.URL.clear